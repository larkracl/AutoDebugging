# scripts/analyze.py
import ast
import sys
import json

def analyze_code(code):
    errors = []
    try:
        tree = ast.parse(code)

        # ZeroDivisionError 검사
        for node in ast.walk(tree):
            if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
                if isinstance(node.right, ast.Constant) and node.right.value == 0:
                    errors.append({
                        'message': 'Potential ZeroDivisionError: Division by zero',
                        'line': node.lineno,
                        'column': node.col_offset,
                        'errorType': 'ZeroDivisionError'
                    })
                elif isinstance(node.right, ast.Num) and node.right.n == 0:
                    errors.append({
                        'message': 'Potential ZeroDivisionError: Division by zero',
                        'line': node.lineno,
                        'column': node.col_offset,
                        'errorType': 'ZeroDivisionError'
                    })


        # NameError 검사 (간단한 버전)
        defined_vars = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                defined_vars.add(node.name)  # 함수 이름도 정의된 변수로 추가
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
                defined_vars.add(node.id)
            elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                if node.id not in defined_vars:
                    errors.append({
                        'message': f"Potential NameError: Name '{node.id}' is not defined",
                        'line': node.lineno,
                        'column': node.col_offset,
                        'errorType': 'NameError'
                    })


    except SyntaxError as e:
        errors.append({
            'message': f"SyntaxError: {e.msg}",
            'line': e.lineno,
            'column': e.offset,
            'errorType': 'SyntaxError'
        })

    return errors

if __name__ == '__main__':
    code = sys.stdin.read()
    errors = analyze_code(code)
    print(json.dumps(errors))