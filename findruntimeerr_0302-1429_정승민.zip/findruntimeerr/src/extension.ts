// src/extension.ts
import * as vscode from "vscode";
import { spawn } from "child_process";
import * as path from "path";

interface ExtensionConfig {
  enable: boolean;
  severityLevel: vscode.DiagnosticSeverity;
  enableDynamicAnalysis: boolean;
  ignoredErrorTypes: string[];
}

interface ErrorInfo {
  message: string;
  line: number;
  column: number;
  errorType: string;
}

export function activate(context: vscode.ExtensionContext) {
  const diagnosticCollection =
    vscode.languages.createDiagnosticCollection("findRuntimeErr");
  context.subscriptions.push(diagnosticCollection);

  const errorDecorationType = vscode.window.createTextEditorDecorationType({
    textDecoration: "underline wavy purple",
  });

  function getConfiguration(): ExtensionConfig {
    const config = vscode.workspace.getConfiguration("findRuntimeErr");
    const severityLevel = config.get<string>("severityLevel", "error");

    let diagnosticSeverity: vscode.DiagnosticSeverity;

    switch (severityLevel) {
      case "warning":
        diagnosticSeverity = vscode.DiagnosticSeverity.Warning;
        break;
      case "information":
        diagnosticSeverity = vscode.DiagnosticSeverity.Information;
        break;
      case "hint":
        diagnosticSeverity = vscode.DiagnosticSeverity.Hint;
        break;
      default:
        diagnosticSeverity = vscode.DiagnosticSeverity.Error;
    }

    return {
      enable: config.get<boolean>("enable", true),
      severityLevel: diagnosticSeverity,
      enableDynamicAnalysis: config.get<boolean>(
        "enableDynamicAnalysis",
        false
      ),
      ignoredErrorTypes: config.get<string[]>("ignoredErrorTypes", []),
    };
  }

  function analyzeCode(
    code: string,
    documentUri: vscode.Uri,
    showStartMessage: boolean = false
  ) {
    diagnosticCollection.clear();
    const config = getConfiguration();
    if (!config.enable) {
      return;
    }

    if (showStartMessage) {
      vscode.window.showInformationMessage("FindRuntimeErr: 검색 시작");
    }

    const pythonScriptPath = path.join(
      context.extensionPath,
      "scripts",
      "analyze.py"
    );
    const pythonProcess = spawn("python3", [pythonScriptPath]);

    let stdoutData = "";
    let stderrData = "";

    pythonProcess.stdin.write(code);
    pythonProcess.stdin.end();

    pythonProcess.stdout.on("data", (data) => {
      stdoutData += data;
    });

    pythonProcess.stderr.on("data", (data) => {
      stderrData += data;
    });

    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        console.error(`Python script exited with code ${code}`);
        console.error(stderrData);
        vscode.window.showErrorMessage(
          `FindRuntimeErr: Error analyzing code. See output for details. ${stderrData}`
        );
        const editor = vscode.window.activeTextEditor;
        if (editor) {
          const fullRange = new vscode.Range(
            0,
            0,
            editor.document.lineCount,
            0
          );
          editor.setDecorations(errorDecorationType, [fullRange]);
        }
        return;
      }

      try {
        const errors: ErrorInfo[] = JSON.parse(stdoutData);
        const diagnostics: vscode.Diagnostic[] = [];
        const decorationRanges: vscode.Range[] = [];

        errors.forEach((error) => {
          if (!config.ignoredErrorTypes.includes(error.errorType)) {
            const range = new vscode.Range(
              error.line - 1,
              error.column,
              error.line - 1,
              error.column + 1
            );

            // Diagnostic 메시지 포맷 변경
            const message = `${error.message} : ${error.errorType} : Line ${error.line}, Column ${error.column} : "AutoDebugging"`;
            const diagnostic = new vscode.Diagnostic(
              range,
              message,
              config.severityLevel
            );
            diagnostic.code = error.errorType; // code 속성은 그대로 유지
            diagnostics.push(diagnostic);
            decorationRanges.push(range);
          }
        });

        diagnosticCollection.set(documentUri, diagnostics);

        const editor = vscode.window.activeTextEditor;
        if (
          editor &&
          editor.document.uri.toString() === documentUri.toString()
        ) {
          editor.setDecorations(errorDecorationType, decorationRanges);
        }
      } catch (parseError) {
        console.error("Error parsing Python script output:", parseError);
        console.error("Raw output:", stdoutData);
        vscode.window.showErrorMessage(
          `FindRuntimeErr: Error parsing analysis results. See output for details. ${parseError}`
        );

        const editor = vscode.window.activeTextEditor;
        if (editor) {
          const fullRange = new vscode.Range(
            0,
            0,
            editor.document.lineCount,
            0
          );
          editor.setDecorations(errorDecorationType, [fullRange]);
        }
      }
    });
  }

  vscode.workspace.onDidChangeTextDocument((event) => {
    if (event.document.languageId === "python") {
      analyzeCode(event.document.getText(), event.document.uri);
    }
  });

  vscode.workspace.onDidOpenTextDocument((document) => {
    if (document.languageId === "python") {
      analyzeCode(document.getText(), document.uri);
    }
  });

  vscode.workspace.onDidChangeConfiguration((e) => {
    if (e.affectsConfiguration("findRuntimeErr")) {
      if (
        vscode.window.activeTextEditor &&
        vscode.window.activeTextEditor.document.languageId === "python"
      ) {
        analyzeCode(
          vscode.window.activeTextEditor.document.getText(),
          vscode.window.activeTextEditor.document.uri
        );
      }
    }
  });

  context.subscriptions.push(
    vscode.commands.registerCommand("findRuntimeErr.analyzeCurrentFile", () => {
      const editor = vscode.window.activeTextEditor;
      if (editor && editor.document.languageId === "python") {
        analyzeCode(editor.document.getText(), editor.document.uri, true);
      } else {
        vscode.window.showWarningMessage(
          "FindRuntimeErr: Please open a Python file to analyze."
        );
      }
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("findRuntimeErr.runDynamicAnalysis", () => {
      const editor = vscode.window.activeTextEditor;
      if (editor && editor.document.languageId === "python") {
        vscode.window.showInformationMessage(
          "FindRuntimeErr: Dynamic analysis is not yet implemented."
        );
      } else {
        vscode.window.showWarningMessage(
          "FindRuntimeErr: Please open a Python file to run dynamic analysis."
        );
      }
    })
  );

  if (
    vscode.window.activeTextEditor &&
    vscode.window.activeTextEditor.document.languageId === "python"
  ) {
    analyzeCode(
      vscode.window.activeTextEditor.document.getText(),
      vscode.window.activeTextEditor.document.uri
    );
  }
}

export function deactivate() {}
