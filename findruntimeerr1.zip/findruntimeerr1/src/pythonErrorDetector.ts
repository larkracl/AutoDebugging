import * as vscode from "vscode";
import { parse } from "@typescript-eslint/parser";

export class PythonErrorDetector
  implements vscode.Disposable, vscode.HoverProvider
{
  private diagnosticCollection: vscode.DiagnosticCollection;
  private checkInterval: number = 5000; // 주기적 체크 간격 (ms)
  private timer: NodeJS.Timeout | null = null;

  constructor() {
    this.diagnosticCollection =
      vscode.languages.createDiagnosticCollection("python");
    vscode.languages.registerHoverProvider("python", this);
    this.startPeriodicCheck(); // 주기적 체크 시작
  }

  // 주기적 체크 시작
  startPeriodicCheck() {
    if (this.timer) {
      clearTimeout(this.timer);
    }
    this.timer = setInterval(() => {
      this.analyzeActiveDocument();
    }, this.checkInterval);
  }

  // 활성 문서 분석 (주기적 체크, command에서 호출)
  analyzeActiveDocument() {
    const activeEditor = vscode.window.activeTextEditor;
    if (activeEditor && activeEditor.document.languageId === "python") {
      this.analyze(activeEditor.document, "Periodic check"); // 로그 메시지에 타입 추가
    }
  }

  provideHover(
    document: vscode.TextDocument,
    position: vscode.Position,
    token: vscode.CancellationToken
  ): vscode.ProviderResult<vscode.Hover> {
    const diagnostics = this.diagnosticCollection.get(document.uri);
    if (!diagnostics) {
      return undefined;
    }

    const relevantDiagnostics = diagnostics.filter((diagnostic) =>
      diagnostic.range.contains(position)
    );
    if (relevantDiagnostics.length === 0) {
      return undefined;
    }

    const diagnostic = relevantDiagnostics[0];
    const hoverMessage = new vscode.MarkdownString();
    hoverMessage.appendMarkdown(`**Error:** ${diagnostic.message}\n\n`);

    if (
      diagnostic.relatedInformation &&
      diagnostic.relatedInformation.length > 0
    ) {
      hoverMessage.appendMarkdown(
        `**Suggestion:** ${diagnostic.relatedInformation[0].message}`
      );
    }

    return new vscode.Hover(hoverMessage);
  }

  analyze(document: vscode.TextDocument, triggerType: string = "File change") {
    console.log(`${triggerType}: Analyzing ${document.fileName}`); // 로그 출력 (타입 포함)

    const diagnostics: vscode.Diagnostic[] = [];

    const astTree = parse(document.getText(), {
      sourceType: "module",
      ecmaVersion: 2015,
    });

    this.checkZeroDivision(astTree, diagnostics, document);
    this.checkUndefinedVariables(astTree, diagnostics, document);

    this.diagnosticCollection.set(document.uri, diagnostics);

    // 문제점 로그 출력
    if (diagnostics.length > 0) {
      console.log(
        `Found ${diagnostics.length} issues in ${document.fileName}:`
      );
      diagnostics.forEach((diagnostic) => {
        console.log(
          `  - ${diagnostic.message} (line ${diagnostic.range.start.line + 1})`
        );
      });
    }
  }

  private checkZeroDivision(
    astTree: any,
    diagnostics: vscode.Diagnostic[],
    document: vscode.TextDocument
  ) {
    class ZeroDivisionVisitor {
      [key: `visit_${string}`]: (node: any) => void;

      visit_BinOp(node: any) {
        if (
          node.op.type === "Div" &&
          node.right.type === "Literal" &&
          node.right.value === 0
        ) {
          const range = new vscode.Range(
            document.positionAt(node.left.start),
            document.positionAt(node.right.end)
          );
          const diagnostic = new vscode.Diagnostic(
            range,
            "ZeroDivisionError: Division by zero detected.",
            vscode.DiagnosticSeverity.Error
          );
          diagnostic.relatedInformation = [
            new vscode.DiagnosticRelatedInformation(
              new vscode.Location(document.uri, range),
              "Consider using dynamic analysis to confirm this error at runtime."
            ),
          ];
          diagnostics.push(diagnostic);
        }
        this.generic_visit(node);
      }
      generic_visit(node: any) {
        for (const key in node) {
          if (node.hasOwnProperty(key)) {
            const child = node[key];
            if (child && typeof child === "object" && child.type) {
              this[`visit_${child.type}`]?.(child);
            } else if (Array.isArray(child)) {
              for (const item of child) {
                if (item && typeof item === "object" && item.type) {
                  this[`visit_${item.type}`]?.(item);
                }
              }
            }
          }
        }
      }

      visit(node: any): void {
        this.generic_visit(node);
      }
    }

    const visitor = new ZeroDivisionVisitor();
    visitor.visit(astTree);
  }

  private checkUndefinedVariables(
    astTree: any,
    diagnostics: vscode.Diagnostic[],
    document: vscode.TextDocument
  ) {
    const definedVariables = new Set<string>();
    class UndefinedVariableVisitor {
      [key: `visit_${string}`]: (node: any) => void;

      visit_FunctionDef(node: any) {
        definedVariables.add(node.id.name);

        node.params.forEach((arg: { name: string }) => {
          definedVariables.add(arg.name);
        });
        this.generic_visit(node);
      }

      visit_Name(node: any) {
        if (!definedVariables.has(node.name)) {
          const range = new vscode.Range(
            document.positionAt(node.start),
            document.positionAt(node.end)
          );
          diagnostics.push(
            new vscode.Diagnostic(
              range,
              `NameError: Name '${node.name}' is not defined.`,
              vscode.DiagnosticSeverity.Error
            )
          );
        }
      }

      generic_visit(node: any) {
        for (const key in node) {
          if (node.hasOwnProperty(key)) {
            const child = node[key];
            if (child && typeof child === "object" && child.type) {
              this[`visit_${child.type}`]?.(child);
            } else if (Array.isArray(child)) {
              for (const item of child) {
                if (item && typeof item === "object" && item.type) {
                  this[`visit_${item.type}`]?.(item);
                }
              }
            }
          }
        }
      }
      visit(node: any): void {
        this.generic_visit(node);
      }
    }
    const visitor = new UndefinedVariableVisitor();
    visitor.visit(astTree.body);
  }

  dispose() {
    this.diagnosticCollection.dispose();
    if (this.timer) {
      clearTimeout(this.timer);
    }
  }
}
