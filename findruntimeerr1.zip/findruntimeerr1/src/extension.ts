import * as vscode from "vscode";
import { PythonErrorDetector } from "./pythonErrorDetector";

export function activate(context: vscode.ExtensionContext) {
  const errorDetector = new PythonErrorDetector();

  // 실시간 분석 (onChange 이벤트 사용)
  vscode.workspace.onDidChangeTextDocument((event) => {
    if (event.document.languageId === "python") {
      errorDetector.analyze(event.document, "File change"); // 타입 명시
    }
  });

  // 초기 분석 (활성화 시)
  vscode.workspace.textDocuments.forEach((document) => {
    if (document.languageId === "python") {
      errorDetector.analyze(document, "Initial analysis"); //타입 명시
    }
  });

  // 사용자 직접 검사 커맨드 등록
  let disposable = vscode.commands.registerCommand(
    "findRuntimeErr.analyzeCurrentFile",
    () => {
      errorDetector.analyzeActiveDocument();
    }
  );

  context.subscriptions.push(errorDetector);
  context.subscriptions.push(disposable); // 커맨드 등록
}

export function deactivate() {}
