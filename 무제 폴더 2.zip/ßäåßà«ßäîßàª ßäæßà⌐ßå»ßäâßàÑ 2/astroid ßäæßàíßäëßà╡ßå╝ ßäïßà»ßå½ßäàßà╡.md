## astroid의 코드 파싱 원리 (AST 생성 과정)

`astroid`는 Python 코드를 파싱하여 추상 구문 트리(Abstract Syntax Tree, AST)를 생성합니다. AST는 코드의 구조를 계층적인 트리 형태로 표현한 것으로, 각 노드는 코드의 구성 요소(문장, 표현식, 연산자, 변수, 함수 등)를 나타냅니다. `astroid`는 Python 표준 라이브러리의 `ast` 모듈을 기반으로 하지만, 더 풍부한 정보와 편리한 API를 제공합니다.

**AST 생성 과정 (단계별 설명):**

1.  **토큰화 (Tokenization):**

    - 입력된 Python 코드(문자열 또는 파일)를 _토큰(token)_ 단위로 분리합니다.
    - 토큰은 의미를 가지는 가장 작은 단위의 코드 조각입니다. (예: 키워드-`if`, `for`, `def` , 식별자-`variable_name`, `function_name`, 연산자-`+`, `-`, `*`, `/`, 리터럴-`10`, `"hello"`, `True`, 구분자-`()`, `[]`, `{}`, `,`, `.`)
    - 토큰화 과정에서는 각 토큰의 유형(type), 값(value), 위치(line number, column offset) 등의 정보가 생성됩니다.

    **예시:**

    ```python
    def my_function(x, y):
        z = x + y
        return z
    ```

    토큰화 결과(간략화):

    | 토큰 유형 | 값            |
    | --------- | ------------- |
    | KEYWORD   | `def`         |
    | NAME      | `my_function` |
    | LPAREN    | `(`           |
    | NAME      | `x`           |
    | COMMA     | `,`           |
    | NAME      | `y`           |
    | RPAREN    | `)`           |
    | COLON     | `:`           |
    | NAME      | `z`           |
    | ASSIGN    | `=`           |
    | NAME      | `x`           |
    | PLUS      | `+`           |
    | NAME      | `y`           |
    | KEYWORD   | `return`      |
    | NAME      | `z`           |

2.  **구문 분석 (Parsing):**

    - 토큰 스트림을 입력받아 Python 문법 규칙에 따라 AST를 구성합니다.
    - `astroid`는 재귀 하향 파서(recursive descent parser)를 사용하여 AST를 생성합니다.
    - 파서는 문법 규칙에 따라 토큰들을 조합하여 더 큰 구조(표현식, 문장)를 만들고, 이를 AST의 노드로 표현합니다.
    - 각 노드는 해당 코드 구조의 종류, 관련된 토큰, 그리고 자식 노드들을 가집니다.

    **AST 노드 유형 (astroid):**

    - `astroid.Module`: 전체 모듈(파일)을 나타내는 최상위 노드.
    - `astroid.FunctionDef`: 함수 정의.
    - `astroid.ClassDef`: 클래스 정의.
    - `astroid.Assign`: 할당문 (변수에 값 할당).
    - `astroid.Name`: 변수, 함수, 클래스 등의 이름(식별자).
    - `astroid.Const`: 상수 (리터럴).
    - `astroid.BinOp`: 이항 연산 (`+`, `-`, `*`, `/` 등).
    - `astroid.UnaryOp`: 단항 연산 (`-`, `not` 등).
    - `astroid.Call`: 함수 호출.
    - `astroid.If`: `if` 문.
    - `astroid.For`: `for` 루프.
    - `astroid.While`: `while` 루프.
    - `astroid.Return`: `return` 문.
    - `astroid.Attribute`: 속성 접근 (`obj.attr`).
    - `astroid.Subscript`: 인덱싱/슬라이싱 (`my_list[i]`).
    - ... (그 외 다양한 노드 유형)

    **예시 (이전 코드의 AST, 간략화):**

    ```
    Module(
      body=[
        FunctionDef(
          name='my_function',
          args=Arguments(
            args=[Name(name='x'), Name(name='y')],
            ...
          ),
          body=[
            Assign(
              targets=[Name(name='z')],
              value=BinOp(
                left=Name(name='x'),
                op='+',
                right=Name(name='y')
              )
            ),
            Return(
              value=Name(name='z')
            )
          ]
        )
      ]
    )
    ```

3.  **의미 분석 (Semantic Analysis) - astroid의 추론:**
    - 생성된 AST를 순회하면서, 타입/값 추론, 스코프 분석, import 분석 등을 수행하여 AST에 추가적인 정보를 부여합니다.
      - 타입 추론(`infer()`): 변수, 표현식의 타입을 추론
      - 스코프 분석(`lookup()`): 변수가 정의된 위치를 찾고, 유효 범위 확인
      - import 분석: import 문을 해석하여 모듈/객체 정보 연결

**도표 (AST 구조 예시):**

```
                 Module
                   |
              FunctionDef (my_function)
              /          |           \
         args(x,y)   body         decorators
                        |
                --------------------
                |                  |
             Assign (z=x+y)      Return (z)
                |                  |
          Name(z) = BinOp          Name(z)
                   /  |  \
             Name(x) + Name(y)

```

**참고 자료:**

- **astroid 공식 문서:** [https://astroid.readthedocs.io/en/latest/](https://astroid.readthedocs.io/en/latest/)
- **astroid GitHub:** [https://github.com/pylint-dev/astroid](https://github.com/pylint-dev/astroid)
- **Python `ast` 모듈 문서:** [https://docs.python.org/3/library/ast.html](https://docs.python.org/3/library/ast.html)
- **Green Tree Snakes (AST 관련 튜토리얼):** [https://greentreesnakes.readthedocs.io/en/latest/](https://greentreesnakes.readthedocs.io/en/latest/)

`astroid`는 `ast` 모듈보다 더 사용자 친화적인 API와 강력한 추론 기능을 제공하여 Python 코드 정적 분석을 훨씬 쉽게 만들어줍니다. `infer()`, `lookup()`, `getattr()` 등의 메서드를 통해 코드의 의미를 파악하고, 잠재적인 오류를 찾을 수 있습니다.
