import * as vscode from "vscode";
import { PythonErrorDetector } from "./pythonErrorDetector";

export function activate(context: vscode.ExtensionContext) {
  const errorDetector = new PythonErrorDetector();

  // 사용자 직접 검사 커맨드 등록
  let disposable = vscode.commands.registerCommand(
    "findRuntimeErr.analyzeCurrentFile",
    async () => {
      await errorDetector.analyzeActiveDocument();
      vscode.window.showInformationMessage("Analyzing current Python file...");
    }
  );

  context.subscriptions.push(errorDetector);
  context.subscriptions.push(disposable);
}

export function deactivate() {}
