import * as vscode from "vscode";

export class PythonErrorDetector
  implements vscode.Disposable, vscode.HoverProvider
{
  private diagnosticCollection: vscode.DiagnosticCollection;

  constructor() {
    this.diagnosticCollection =
      vscode.languages.createDiagnosticCollection("python");
    vscode.languages.registerHoverProvider("python", this);
    // 실시간 분석 (파일 변경 감지)
    vscode.workspace.onDidChangeTextDocument((event) => {
      if (event.document.languageId === "python") {
        this.analyze(event.document);
      }
    });
  }

  provideHover(
    document: vscode.TextDocument,
    position: vscode.Position,
    token: vscode.CancellationToken
  ): vscode.ProviderResult<vscode.Hover> {
    const diagnostics = this.diagnosticCollection.get(document.uri);
    if (!diagnostics) {
      return undefined;
    }

    const relevantDiagnostics = diagnostics.filter((diagnostic) =>
      diagnostic.range.contains(position)
    );
    if (relevantDiagnostics.length === 0) {
      return undefined;
    }

    const diagnostic = relevantDiagnostics[0];
    const hoverMessage = new vscode.MarkdownString();
    hoverMessage.appendMarkdown(`**Error:** ${diagnostic.message}\n\n`);

    if (
      diagnostic.relatedInformation &&
      diagnostic.relatedInformation.length > 0
    ) {
      hoverMessage.appendMarkdown(
        `**Suggestion:** ${diagnostic.relatedInformation[0].message}`
      );
    }

    return new vscode.Hover(hoverMessage);
  }

  // 활성 편집기의 Python 코드 분석 (command에서 호출)
  async analyzeActiveDocument() {
    const activeEditor = vscode.window.activeTextEditor;
    if (activeEditor && activeEditor.document.languageId === "python") {
      await this.analyze(activeEditor.document);
    } else {
      vscode.window.showWarningMessage("No active Python editor found.");
    }
  }

  async analyze(document: vscode.TextDocument) {
    console.log(`Analyzing ${document.fileName}`);

    const diagnostics: vscode.Diagnostic[] = [];

    // 1. Python 스크립트를 실행하여 AST를 얻어옴 (child_process 사용)
    let astTree: any;
    try {
      astTree = await this.getAstFromPython(document.getText());
    } catch (error) {
      console.error("Failed to get AST from Python:", error);
      if (error instanceof Error) {
        const range = new vscode.Range(0, 0, 0, 0); // 또는 오류 위치
        const diagnostic = new vscode.Diagnostic(
          range,
          `Failed to analyze code: ${error.message}`,
          vscode.DiagnosticSeverity.Error
        );
        diagnostics.push(diagnostic);
      }
      this.diagnosticCollection.set(document.uri, diagnostics); // 오류 보고
      return;
    }

    // 2. 오류 검사 규칙 적용
    this.checkZeroDivision(astTree, diagnostics, document);
    this.checkUndefinedVariables(astTree, diagnostics, document);

    // 3. 오류 보고
    this.diagnosticCollection.set(document.uri, diagnostics);

    if (diagnostics.length > 0) {
      console.log(
        `Found ${diagnostics.length} issues in ${document.fileName}:`
      );
      diagnostics.forEach((diagnostic) => {
        console.log(
          `  - ${diagnostic.message} (line ${diagnostic.range.start.line + 1})`
        );
      });
    }
  }

  // Python 스크립트를 실행하여 AST를 얻어오는 함수 (비동기)
  private async getAstFromPython(code: string): Promise<any> {
    return new Promise((resolve, reject) => {
      const pythonProcess = require("child_process").spawn(
        "/venv/bin/python3",
        ["-c", `import ast; print(ast.dump(ast.parse("""${code}""")))`]
      );
      // Python 3 사용, python3 없으면 python으로 변경

      let output = "";
      pythonProcess.stdout.on("data", (data: string) => {
        output += data;
      });

      pythonProcess.stderr.on("data", (data: string) => {
        reject(data); // stderr 출력을 오류로 처리
      });

      pythonProcess.on("close", (code: number) => {
        if (code === 0) {
          try {
            const parsed = this.parseAstDump(output);
            resolve(parsed); // 성공적으로 AST를 얻으면 resolve
          } catch (error) {
            reject(error);
          }
        } else {
          reject(`Python process exited with code ${code}`); // 오류 코드와 함께 reject
        }
      });
    });
  }
  private checkZeroDivision(
    astTree: any,
    diagnostics: vscode.Diagnostic[],
    document: vscode.TextDocument
  ) {
    const visitor = (node: any) => {
      if (node._type === "BinOp" && node.op._type === "Div") {
        if (node.right._type === "Constant" && node.right.value === 0) {
          const range = new vscode.Range(
            new vscode.Position(node.lineno - 1, node.col_offset),
            new vscode.Position(node.lineno - 1, node.col_offset + 1) //임시
          );
          const diagnostic = new vscode.Diagnostic(
            range,
            "ZeroDivisionError: Division by zero detected.",
            vscode.DiagnosticSeverity.Error
          );
          diagnostic.relatedInformation = [
            new vscode.DiagnosticRelatedInformation(
              new vscode.Location(document.uri, range),
              "Consider using dynamic analysis to confirm this error at runtime."
            ),
          ];
          diagnostics.push(diagnostic);
        }
      }

      // 자식 노드 방문
      for (const key in node) {
        if (node.hasOwnProperty(key)) {
          const child = node[key];
          if (Array.isArray(child)) {
            for (const item of child) {
              if (item && typeof item === "object") {
                visitor(item);
              }
            }
          } else if (child && typeof child === "object") {
            visitor(child);
          }
        }
      }
    };

    visitor(astTree);
  }

  private checkUndefinedVariables(
    astTree: any,
    diagnostics: vscode.Diagnostic[],
    document: vscode.TextDocument
  ) {
    const definedVariables = new Set<string>();

    const visitor = (node: any) => {
      // 변수 정의 (FunctionDef, Assign)
      if (node._type === "FunctionDef") {
        definedVariables.add(node.name);
        node.args.args.forEach((arg: { arg: string }) => {
          definedVariables.add(arg.arg);
        });
      } else if (node._type === "Name" && node.ctx._type === "Store") {
        definedVariables.add(node.id);
      }

      // 변수 사용 (Name)
      if (node._type === "Name" && node.ctx._type === "Load") {
        if (!definedVariables.has(node.id)) {
          const range = new vscode.Range(
            new vscode.Position(node.lineno - 1, node.col_offset),
            new vscode.Position(node.lineno - 1, node.col_offset + 1) //임시
          );
          diagnostics.push(
            new vscode.Diagnostic(
              range,
              `NameError: Name '${node.id}' is not defined.`,
              vscode.DiagnosticSeverity.Error
            )
          );
        }
      }

      // 자식 노드 방문
      for (const key in node) {
        if (node.hasOwnProperty(key)) {
          const child = node[key];
          if (Array.isArray(child)) {
            for (const item of child) {
              if (item && typeof item === "object") {
                visitor(item);
              }
            }
          } else if (child && typeof child === "object") {
            visitor(child);
          }
        }
      }
    };

    visitor(astTree);
  }

  dispose() {
    this.diagnosticCollection.dispose();
  }
  parseAstDump(dumpOutput: string): any {
    const astData = {};

    // 정규 표현식을 사용하여 노드 타입, 필드 이름, 값 추출
    const nodeRegex = /(\w+)\((.*?)\)/g;
    const fieldRegex = /(\w+)=((?:(?!\w+=)[^,])+)/g;

    let nodeMatch;
    while ((nodeMatch = nodeRegex.exec(dumpOutput)) !== null) {
      const nodeType = nodeMatch[1];
      const fieldsString = nodeMatch[2];

      const nodeData: any = { _type: nodeType };

      let fieldMatch;
      while ((fieldMatch = fieldRegex.exec(fieldsString)) !== null) {
        const fieldName = fieldMatch[1];
        const fieldValue = fieldMatch[2];
        nodeData[fieldName] = fieldValue;
      }

      // 스택을 사용하여 노드 간의 계층 관계 처리
      const stack = [astData];
      let current: any = stack[0];
      for (const key in nodeData) {
        if (key === "_type") continue;
        if (typeof nodeData[key] === "string" && nodeData[key].includes("(")) {
          let next;
          while ((nodeMatch = nodeRegex.exec(nodeData[key])) !== null) {
            next = { _type: nodeMatch[1] };
            current[key] = next;
            current = next;
          }
        } else {
          current[key] = this.parseValue(nodeData[key]);
        }
      }
      Object.assign(astData, current);
    }

    return astData;
  }

  parseValue(value: string): any {
    // 간단한 값 타입 파싱 (정수, 문자열 등)
    if (/^['"].*['"]$/.test(value)) {
      return value.slice(1, -1); // 따옴표 제거
    } else if (/^-?\d+$/.test(value)) {
      return parseInt(value, 10); // 정수
    } else if (value === "True") {
      return true;
    } else if (value === "False") {
      return false;
    } else {
      return value;
    }
  }
}
