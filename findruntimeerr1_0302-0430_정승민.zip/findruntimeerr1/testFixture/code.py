# 기본적인 0으로 나누기
x = 10
y = 0
z = x / y  # ZeroDivisionError 발생

# 함수 내에서 0으로 나누기
def divide(a, b):
    return a / b  # ZeroDivisionError 발생 가능

result = divide(5, 0)

# 조건문 내에서 0으로 나누기
if True:
    a = 1
    b = 0
    c = a / b # ZeroDivisionError
    
print(num)
print(time)
# 리스트 컴프리헨션 내에서 0으로 나누기
numbers = [1, 2, 0, 4]
results = [10 / n for n in numbers]  # ZeroDivisionError 발생

print(num)