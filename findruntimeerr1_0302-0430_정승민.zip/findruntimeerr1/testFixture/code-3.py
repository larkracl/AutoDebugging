# 정상적인 코드 (오류 없음)
x = 10
y = 2
z = x / y
print(z)

def add(a, b):
    return a + b

result = add(5, 3)
print(result)

if True:
    a = 1
    b = 2
    c = a + b
    print(c)

numbers = [1, 2, 3, 4]
results = [10 / n for n in numbers]
print(results)

def defined_function():
  local_var = 5;
  print(local_var)

defined_function()