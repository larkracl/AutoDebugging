# 정의되지 않은 변수 사용
print(undefined_var)  # NameError 발생

# 함수 내에서 정의되지 않은 변수 사용
def my_function():
    print(another_undefined_var)  # NameError 발생

my_function()

# 조건문 내에서 정의되지 않은 변수 사용
if True:
    print(yet_another_undefined_var) # NameError

# 다른 스코프의 변수 사용 (주의: 현재 코드로는 탐지 어려움)
def outer_function():
    outer_var = 10

def inner_function():
    print(outer_var)  # NameError (현재는 탐지 안 됨)

inner_function()