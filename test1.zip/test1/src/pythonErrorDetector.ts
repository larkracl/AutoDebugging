import * as vscode from "vscode";
import { parse } from "@typescript-eslint/parser";

export class PythonErrorDetector
  implements vscode.Disposable, vscode.HoverProvider
{
  // HoverProvider 추가
  private diagnosticCollection: vscode.DiagnosticCollection;

  constructor() {
    this.diagnosticCollection =
      vscode.languages.createDiagnosticCollection("python");
    vscode.languages.registerHoverProvider("python", this); // HoverProvider 등록
  }
  provideHover(
    document: vscode.TextDocument,
    position: vscode.Position,
    token: vscode.CancellationToken
  ): vscode.ProviderResult<vscode.Hover> {
    const diagnostics = this.diagnosticCollection.get(document.uri);
    if (!diagnostics) {
      return undefined;
    }

    const relevantDiagnostics = diagnostics.filter((diagnostic) =>
      diagnostic.range.contains(position)
    );
    if (relevantDiagnostics.length === 0) {
      return undefined;
    }

    // 호버 메시지 생성 (여기서는 첫 번째 오류 메시지만 사용)
    const diagnostic = relevantDiagnostics[0];
    const hoverMessage = new vscode.MarkdownString();
    hoverMessage.appendMarkdown(`**Error:** ${diagnostic.message}\n\n`);

    if (
      diagnostic.relatedInformation &&
      diagnostic.relatedInformation.length > 0
    ) {
      hoverMessage.appendMarkdown(
        `**Suggestion:** ${diagnostic.relatedInformation[0].message}`
      );
    }

    return new vscode.Hover(hoverMessage);
  }

  analyze(document: vscode.TextDocument) {
    const diagnostics: vscode.Diagnostic[] = [];

    // 1. AST 파싱
    const astTree = parse(document.getText(), {
      sourceType: "module",
      ecmaVersion: 2015,
    });

    // 2. 오류 검사 규칙 적용
    this.checkZeroDivision(astTree, diagnostics, document);
    this.checkUndefinedVariables(astTree, diagnostics, document);

    // 3. 오류 보고
    this.diagnosticCollection.set(document.uri, diagnostics);
  }

  // 0으로 나누기 검사 (ast 모듈 버전)
  private checkZeroDivision(
    astTree: any,
    diagnostics: vscode.Diagnostic[],
    document: vscode.TextDocument
  ) {
    class ZeroDivisionVisitor {
      [key: `visit_${string}`]: (node: any) => void; // 인덱스 시그니처

      visit_BinOp(node: any) {
        if (
          node.op.type === "Div" &&
          node.right.type === "Literal" &&
          node.right.value === 0
        ) {
          const range = new vscode.Range(
            document.positionAt(node.left.start),
            document.positionAt(node.right.end)
          );
          const diagnostic = new vscode.Diagnostic(
            range,
            "ZeroDivisionError: Division by zero detected.",
            vscode.DiagnosticSeverity.Error
          );
          diagnostic.relatedInformation = [
            new vscode.DiagnosticRelatedInformation(
              new vscode.Location(document.uri, range),
              "Consider using dynamic analysis to confirm this error at runtime."
            ),
          ];
          diagnostics.push(diagnostic);
        }
        this.generic_visit(node);
      }
      generic_visit(node: any) {
        for (const key in node) {
          if (node.hasOwnProperty(key)) {
            const child = node[key];
            if (child && typeof child === "object" && child.type) {
              // @ts-ignore
              this[`visit_${child.type}`]?.(child);
            } else if (Array.isArray(child)) {
              for (const item of child) {
                if (item && typeof item === "object" && item.type) {
                  // @ts-ignore
                  this[`visit_${item.type}`]?.(item);
                }
              }
            }
          }
        }
      }

      visit(node: any): void {
        this.generic_visit(node);
      }
    }

    const visitor = new ZeroDivisionVisitor();
    visitor.visit(astTree);
  }

  // 정의되지 않은 변수 검사 (ast 모듈 버전, 개선 필요)
  private checkUndefinedVariables(
    astTree: any,
    diagnostics: vscode.Diagnostic[],
    document: vscode.TextDocument
  ) {
    const definedVariables = new Set<string>();
    class UndefinedVariableVisitor {
      [key: `visit_${string}`]: (node: any) => void; // 인덱스 시그니처

      visit_FunctionDef(node: any) {
        definedVariables.add(node.id.name);

        node.params.forEach((arg: { name: string }) => {
          definedVariables.add(arg.name);
        });
        this.generic_visit(node);
      }

      visit_Name(node: any) {
        if (!definedVariables.has(node.name)) {
          const range = new vscode.Range(
            document.positionAt(node.start),
            document.positionAt(node.end)
          );
          diagnostics.push(
            new vscode.Diagnostic(
              range,
              `NameError: Name '${node.name}' is not defined.`,
              vscode.DiagnosticSeverity.Error
            )
          );
        }
      }

      generic_visit(node: any) {
        for (const key in node) {
          if (node.hasOwnProperty(key)) {
            const child = node[key];
            if (child && typeof child === "object" && child.type) {
              // @ts-ignore
              this[`visit_${child.type}`]?.(child);
            } else if (Array.isArray(child)) {
              for (const item of child) {
                if (item && typeof item === "object" && item.type) {
                  // @ts-ignore
                  this[`visit_${item.type}`]?.(item);
                }
              }
            }
          }
        }
      }
      visit(node: any): void {
        this.generic_visit(node);
      }
    }
    const visitor = new UndefinedVariableVisitor();
    visitor.visit(astTree.body);
  }

  dispose() {
    this.diagnosticCollection.dispose();
  }
}
