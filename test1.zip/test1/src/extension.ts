// src/extension.ts (entry point)

import * as vscode from "vscode";
import { PythonErrorDetector } from "./pythonErrorDetector";

export function activate(context: vscode.ExtensionContext) {
  const errorDetector = new PythonErrorDetector();

  // 실시간 분석 (onChange 이벤트 사용)
  vscode.workspace.onDidChangeTextDocument((event) => {
    if (event.document.languageId === "python") {
      errorDetector.analyze(event.document);
    }
  });

  // 초기 분석 (활성화 시)
  vscode.workspace.textDocuments.forEach((document) => {
    if (document.languageId === "python") {
      errorDetector.analyze(document);
    }
  });

  context.subscriptions.push(errorDetector);
}

export function deactivate() {}
